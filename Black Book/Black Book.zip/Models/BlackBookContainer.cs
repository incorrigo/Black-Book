﻿using System.Collections.Generic;
using BlackBook.Models;

namespace BlackBook.Storage;

public class BlackBookContainer {
    public List<Person> People { get; set; } = new();
    public List<Company> Companies { get; set; } = new();
    public List<Interaction> Interactions { get; set; } = new();
    public List<Situation> Situations { get; set; } = new();

    public DateTime Created { get; set; } = DateTime.UtcNow;
    public DateTime LastOpened { get; set; } = DateTime.UtcNow;
    public int AccessCount { get; set; } = 0;
    public string Version { get; set; } = "1.0.0";

    public void Clear () {
        People.Clear();
        Companies.Clear();
        Interactions.Clear();
        Situations.Clear();
    }
}
