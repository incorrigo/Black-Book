﻿using BlackBook.Models;
using BlackBook.Security;
using BlackBook.Storage;
using BlackBook.Views;
/// INCORRIGO SYX DIGITAL COMMUNICATION SYSTEMS
// 2025-06-26 [Thursday]
///
// [BlackBook/MainWindow.xaml.cs]

using System;
using System.Windows;

namespace BlackBook;

    public partial class MainWindow : Window {
        public MainWindow () {
            InitializeComponent();
            DataContext = BlackBookContainer.Instance;
        }

        #region File Menu
        private void Logout_Click (object sender, RoutedEventArgs e) {
            try {
                await SecureProfileManager.SaveProfileAsync(
                SessionManager.CurrentUserName,
                SessionManager.CurrentPassword,
                SessionManager.Data!,
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Users")
);

                new InitialLoginWindow().Show();
                Close();
            }
            catch (Exception ex) {
                MessageBox.Show($"Logout failed: {ex.Message}",
                    "Black Book", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void Exit_Click (object sender, RoutedEventArgs e) => Close();
        #endregion

        #region New Entity Shortcuts
        private void NewPerson_Click (object sender, RoutedEventArgs e) {
            // quick host window around the PeopleManager editor panel
            var host = new Window {
                Title = "New Person",
                Content = new PeopleManager { Margin = new Thickness(12) },
                SizeToContent = SizeToContent.WidthAndHeight,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this
            };
            host.ShowDialog();
        }

        private void NewSituation_Click (object sender, RoutedEventArgs e) {
            new SituationManager().ShowDialog();     // renamed window
        }

        private void NewCorrespondence_Click (object sender, RoutedEventArgs e) {
            new CorrespondenceEntryWindow().ShowDialog();
        }
        #endregion
    }
}
