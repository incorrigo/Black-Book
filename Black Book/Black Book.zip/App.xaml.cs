﻿using System.Windows;

namespace BlackBook;

public partial class App : Application {
}
