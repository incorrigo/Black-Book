﻿/// INCORRIGO SYX DIGITAL COMMUNICATION SYSTEMS
// 2025-06-26 [Thursday]
///
// [BlackBook/RelationshipMap.xaml.cs]

using System.Windows.Controls;

namespace BlackBook.Views;

public partial class RelationshipMap : UserControl {
    public RelationshipMap () {
        InitializeComponent();
    }
}
