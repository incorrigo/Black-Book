﻿/// INCORRIGO SYX DIGITAL COMMUNICATION SYSTEMS
// 2025-06-25 [Wednesday]
///
// [BlackBook/ProjectFolder/PeopleManager.xaml.cs]

using System.Windows.Controls;

namespace BlackBook.Views;

    public partial class PeopleManager : UserControl {
        public PeopleManager () {
            InitializeComponent();
        }
    }

