﻿/// INCORRIGO SYX DIGITAL COMMUNICATION SYSTEMS
// 2025-06-26 [Thursday]
///
// [BlackBook/SituationManager.xaml.cs]

using System.Windows.Controls;

namespace BlackBook.Views;
    public partial class SituationManager : UserControl {
        public SituationManager () {
            InitializeComponent();
        }
    }

